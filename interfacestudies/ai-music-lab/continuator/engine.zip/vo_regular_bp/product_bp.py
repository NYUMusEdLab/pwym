"""Sum-product and max-plus DP on reachable context-acceptor products."""

from __future__ import annotations

from dataclasses import dataclass, field
import random
import math
from typing import Hashable, Iterable, Sequence

from .acceptors import DFA, transition_weight as regular_transition_weight
from .context import Context, ContextModel, Symbol, _as_context

from ._numerics import NEG_INF, log_mass, log_sum, mass_from_log, relative_weights

ProductState = tuple[Context, Hashable]


@dataclass(frozen=True)
class ProductEdge:
    symbol: Symbol
    probability: float
    transition_weight: float
    next_state: ProductState
    order_weights: tuple[tuple[int, float], ...] = ()


@dataclass(frozen=True)
class MostProbableSequenceResult:
    """An optimum sequence and its unnormalized natural-log path weight.

    Infeasibility is represented by ``sequence=None`` and ``log_weight=-inf``.
    The accepted empty sequence is ``()`` with log weight zero.
    """

    sequence: tuple[Symbol, ...] | None
    log_weight: float

    @property
    def feasible(self) -> bool:
        return self.sequence is not None


@dataclass
class ProductBPResult:
    graph: ContextModel
    acceptor: DFA
    length: int
    start_state: ProductState
    layers: list[set[ProductState]]
    edges: list[dict[ProductState, tuple[ProductEdge, ...]]]
    betas: list[dict[ProductState, float]]
    _transition_weight_cache: dict[tuple[int, ProductState], tuple[tuple[ProductEdge, float], ...]] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )

    _log_betas: list[dict[ProductState, float]] | None = field(default=None, repr=False)

    @property
    def log_partition_function(self) -> float:
        if self._log_betas is not None:
            return self._log_betas[0].get(self.start_state, NEG_INF)
        return log_mass(self.partition_function)

    @property
    def partition_function(self) -> float:
        return self.betas[0].get(self.start_state, 0.0)

    @property
    def unique_product_state_count(self) -> int:
        return len(set().union(*self.layers)) if self.layers else 0

    @property
    def time_indexed_product_state_count(self) -> int:
        return sum(len(layer) for layer in self.layers)

    @property
    def product_edge_count(self) -> int:
        return sum(len(edges) for layer_edges in self.edges for edges in layer_edges.values())

    @property
    def reachable_acceptor_state_count(self) -> int:
        return len({state for layer in self.layers for _, state in layer})

    def transition_weights(self, time: int, state: ProductState) -> tuple[tuple[ProductEdge, float], ...]:
        """Return outgoing product edges and their conditional sampling weights."""

        if time < 0 or time >= self.length:
            raise ValueError("time is outside the BP horizon")
        cache_key = (time, state)
        if cache_key in self._transition_weight_cache:
            return self._transition_weight_cache[cache_key]

        if self._log_betas is not None:
            edges = self.edges[time].get(state, ())
            logs = tuple(
                log_mass(edge.probability)
                + log_mass(edge.transition_weight)
                + self._log_betas[time + 1].get(edge.next_state, NEG_INF)
                for edge in edges
            )
            result = tuple(
                (edge, weight) for edge, weight in zip(edges, relative_weights(logs)) if weight > 0
            )
            self._transition_weight_cache[cache_key] = result
            return result
        beta_next = self.betas[time + 1]
        weighted = []
        for edge in self.edges[time].get(state, ()):
            weight = (
                edge.probability
                * edge.transition_weight
                * beta_next.get(edge.next_state, 0.0)
            )
            if weight > 0.0:
                weighted.append((edge, weight))
        result = tuple(weighted)
        self._transition_weight_cache[cache_key] = result
        return result

    def _sample_edge(self, time: int, state: ProductState, generator: random.Random) -> ProductEdge:
        weighted = self.transition_weights(time, state)
        total = sum(weight for _, weight in weighted)
        if total <= 0.0:
            raise RuntimeError("BP table contains no positive continuation for a reachable state")
        threshold = generator.random() * total
        cumulative = 0.0
        chosen = weighted[-1][0]
        for edge, weight in weighted:
            cumulative += weight
            if threshold <= cumulative:
                return edge
        return chosen

    def sample(self, *, rng: random.Random | int | None = None) -> tuple[Symbol, ...]:
        """Draw one exact sample from the constrained distribution."""

        generator = _coerce_rng(rng)
        if self.log_partition_function == NEG_INF:
            raise ValueError("cannot sample because the constrained partition function is zero")

        state = self.start_state
        output: list[Symbol] = []
        for time in range(self.length):
            chosen = self._sample_edge(time, state, generator)
            output.append(chosen.symbol)
            state = chosen.next_state
        return tuple(output)

    def sample_many(self, count: int, *, rng: random.Random | int | None = None) -> list[tuple[Symbol, ...]]:
        generator = _coerce_rng(rng)
        return [self.sample(rng=generator) for _ in range(count)]

    def sample_with_orders(
        self,
        *,
        rng: random.Random | int | None = None,
    ) -> tuple[tuple[Symbol, ...], tuple[int, ...]]:
        """Draw one exact sample and a latent order used at each event.

        For explicit backoff edges, the order is sampled from the posterior
        contribution of each suffix order to the selected symbol. For ordinary
        MLE edges without order metadata, the current context length is used.
        """

        generator = _coerce_rng(rng)
        if self.log_partition_function == NEG_INF:
            raise ValueError("cannot sample because the constrained partition function is zero")

        state = self.start_state
        output: list[Symbol] = []
        orders: list[int] = []
        for time in range(self.length):
            chosen = self._sample_edge(time, state, generator)
            output.append(chosen.symbol)
            orders.append(_sample_order(chosen.order_weights, generator))
            state = chosen.next_state
        return tuple(output), tuple(orders)

    def sample_many_with_orders(
        self,
        count: int,
        *,
        rng: random.Random | int | None = None,
    ) -> list[tuple[tuple[Symbol, ...], tuple[int, ...]]]:
        generator = _coerce_rng(rng)
        return [self.sample_with_orders(rng=generator) for _ in range(count)]

    def conditional_probability(self, sequence: Sequence[Symbol]) -> float:
        """Probability of ``sequence`` under the constrained BP distribution."""

        if len(sequence) != self.length:
            raise ValueError("sequence length must match the BP horizon")
        if self.log_partition_function == NEG_INF:
            return 0.0

        if self._log_betas is not None:
            return mass_from_log(self.log_conditional_probability(sequence))

        state = self.start_state
        probability = 1.0
        for time, symbol in enumerate(sequence):
            beta_now = self.betas[time].get(state, 0.0)
            if beta_now <= 0.0:
                return 0.0
            edge = next(
                (
                    edge
                    for edge in self.edges[time].get(state, ())
                    if edge.symbol == symbol
                ),
                None,
            )
            if edge is None:
                return 0.0
            weight = (
                edge.probability
                * edge.transition_weight
                * self.betas[time + 1].get(edge.next_state, 0.0)
            )
            if weight <= 0.0:
                return 0.0
            probability *= weight / beta_now
            state = edge.next_state
        return probability

    def log_conditional_probability(self, sequence: Sequence[Symbol]) -> float:
        if len(sequence) != self.length:
            raise ValueError("sequence length must match the BP horizon")
        if self.log_partition_function == NEG_INF:
            return NEG_INF
        state = self.start_state
        log_probability = 0.0
        for time, symbol in enumerate(sequence):
            edge = next((e for e in self.edges[time].get(state, ()) if e.symbol == symbol), None)
            if edge is None or edge.probability <= 0 or edge.transition_weight <= 0:
                return NEG_INF
            log_probability += log_mass(edge.probability) + log_mass(edge.transition_weight)
            state = edge.next_state
        if not self.acceptor.is_accepting(state[1]):
            return NEG_INF
        return min(0.0, log_probability - self.log_partition_function)


def _build_product_graph(
    graph: ContextModel,
    acceptor: DFA,
    *,
    length: int,
    start_context: Iterable[Symbol] | Context | None = None,
    start_acceptor_state: Hashable | None = None,
) -> tuple[
    ProductState,
    list[set[ProductState]],
    list[dict[ProductState, tuple[ProductEdge, ...]]],
]:
    """Build horizon-reachable rows once, preserving outgoing edge order."""

    if length < 0:
        raise ValueError("length must be non-negative")

    context0 = graph.start_state if start_context is None else _as_context(start_context)
    acceptor0 = acceptor.start_state if start_acceptor_state is None else start_acceptor_state
    start = (context0, acceptor0)

    layers: list[set[ProductState]] = [set([start])]
    edges_by_time: list[dict[ProductState, tuple[ProductEdge, ...]]] = []

    transition_rows: dict[ProductState, tuple[ProductEdge, ...]] = {}
    for _time in range(length):
        current_layer = layers[-1]
        next_layer: set[ProductState] = set()
        current_edges: dict[ProductState, tuple[ProductEdge, ...]] = {}

        for context_state, acceptor_state in current_layer:
            state = (context_state, acceptor_state)
            if state not in transition_rows:
                product_edges = []
                for edge in graph.outgoing(context_state):
                    next_acceptor_state = acceptor.next_state(acceptor_state, edge.symbol)
                    if next_acceptor_state is None:
                        continue
                    dfa_weight = regular_transition_weight(acceptor, acceptor_state, edge.symbol)
                    if dfa_weight <= 0.0:
                        continue
                    next_product_state = (edge.next_state, next_acceptor_state)
                    product_edges.append(
                        ProductEdge(
                            symbol=edge.symbol,
                            probability=edge.probability,
                            transition_weight=dfa_weight,
                            next_state=next_product_state,
                            order_weights=edge.order_weights or ((len(context_state), 1.0),),
                        )
                    )
                transition_rows[state] = tuple(product_edges)
            row = transition_rows[state]
            current_edges[state] = row
            next_layer.update(edge.next_state for edge in row)

        edges_by_time.append(current_edges)
        layers.append(next_layer)

    return start, layers, edges_by_time


def most_probable_sequence(
    graph: ContextModel,
    acceptor: DFA,
    *,
    length: int,
    start_context: Iterable[Symbol] | Context | None = None,
    start_acceptor_state: Hashable | None = None,
) -> MostProbableSequenceResult:
    """Maximize unnormalized path weight on a fixed-horizon product graph.

    Uses the same model as :func:`run_bp`: source probabilities multiplied by
    acceptor transition weights, unit initial weight, and Boolean terminal
    acceptance. Explicit backoff mixtures (including lazy models) are supported;
    policy-driven order stacks are not. Start overrides select the state before
    the first emission; no prefix weight is included.

    Max-plus DP uses natural logs of the individual positive float factors,
    without computing a partition function or multiplying factors first. This
    avoids path-product underflow/overflow, but logs and additions still round:
    nearly equal real weights may be misordered or become computed ties. No
    exact-real or rational optimality certificate is provided. On exactly equal
    computed scores, the first edge in ``graph.outgoing(context)`` wins at each
    position; symbols are never sorted and no tolerance is applied. Stable row
    ordering therefore gives deterministic ties, independently of state-set
    iteration order.

    Returns ``sequence=None``, ``log_weight=-inf``, and ``feasible=False`` when
    no positive-weight accepted path exists. A negative length raises ValueError.
    """

    start, layers, edges_by_time = _build_product_graph(
        graph,
        acceptor,
        length=length,
        start_context=start_context,
        start_acceptor_state=start_acceptor_state,
    )
    scores = {state: 0.0 for state in layers[length] if acceptor.is_accepting(state[1])}
    choices: list[dict[ProductState, ProductEdge]] = [{} for _ in range(length)]
    for time in range(length - 1, -1, -1):
        current_scores: dict[ProductState, float] = {}
        for state, edges in edges_by_time[time].items():
            best_score = NEG_INF
            for edge in edges:
                suffix_score = scores.get(edge.next_state, NEG_INF)
                if edge.probability <= 0.0 or suffix_score == NEG_INF:
                    continue
                score = (
                    log_mass(edge.probability)
                    + log_mass(edge.transition_weight)
                    + suffix_score
                )
                if score > best_score:
                    best_score = score
                    choices[time][state] = edge
            if best_score != NEG_INF:
                current_scores[state] = best_score
        scores = current_scores

    log_weight = scores.get(start, NEG_INF)
    if log_weight == NEG_INF:
        return MostProbableSequenceResult(sequence=None, log_weight=NEG_INF)

    state = start
    sequence: list[Symbol] = []
    for time in range(length):
        edge = choices[time][state]
        sequence.append(edge.symbol)
        state = edge.next_state
    return MostProbableSequenceResult(sequence=tuple(sequence), log_weight=log_weight)


def run_bp(
    graph: ContextModel,
    acceptor: DFA,
    *,
    length: int,
    start_context: Iterable[Symbol] | Context | None = None,
    start_acceptor_state: Hashable | None = None,
) -> ProductBPResult:
    """Run exact backward DP on the reachable product for a fixed horizon."""

    start, layers, edges_by_time = _build_product_graph(
        graph,
        acceptor,
        length=length,
        start_context=start_context,
        start_acceptor_state=start_acceptor_state,
    )
    betas: list[dict[ProductState, float]] = [dict() for _ in range(length + 1)]
    betas[length] = {
        state: 1.0 if acceptor.is_accepting(state[1]) else 0.0
        for state in layers[length]
    }

    needs_log = False
    for time in range(length - 1, -1, -1):
        beta_next = betas[time + 1]
        beta_now: dict[ProductState, float] = {}
        for state in layers[time]:
            beta_now[state] = sum(
                edge.probability
                * edge.transition_weight
                * beta_next.get(edge.next_state, 0.0)
                for edge in edges_by_time[time].get(state, ())
            )
        betas[time] = beta_now
        if any(
            not math.isfinite(value) or 0 < value < 1e-200 or value > 1e200
            for value in beta_now.values()
        ):
            needs_log = True
        if not needs_log:
            needs_log = any(
                edge.probability > 0
                and edge.transition_weight > 0
                and beta_next.get(edge.next_state, 0) > 0
                and edge.probability * edge.transition_weight * beta_next[edge.next_state] == 0
                for state, value in beta_now.items()
                if value == 0
                for edge in edges_by_time[time].get(state, ())
            )

    log_betas = None
    if needs_log:
        log_betas = [{} for _ in range(length + 1)]
        log_betas[length] = {state: log_mass(value) for state, value in betas[length].items()}
        for time in range(length - 1, -1, -1):
            log_betas[time] = {
                state: log_sum(
                    log_mass(edge.probability)
                    + log_mass(edge.transition_weight)
                    + log_betas[time + 1].get(edge.next_state, NEG_INF)
                    for edge in edges_by_time[time].get(state, ())
                )
                for state in layers[time]
            }
            betas[time] = {state: mass_from_log(value) for state, value in log_betas[time].items()}

    return ProductBPResult(
        graph=graph,
        acceptor=acceptor,
        length=length,
        start_state=start,
        layers=layers,
        edges=edges_by_time,
        betas=betas,
        _log_betas=log_betas,
    )


def sample_exact(
    graph: ContextModel,
    acceptor: DFA,
    *,
    length: int,
    rng: random.Random | int | None = None,
    start_context: Iterable[Symbol] | Context | None = None,
    start_acceptor_state: Hashable | None = None,
) -> tuple[Symbol, ...]:
    """Convenience wrapper: run BP and draw one exact sample."""

    result = run_bp(
        graph,
        acceptor,
        length=length,
        start_context=start_context,
        start_acceptor_state=start_acceptor_state,
    )
    return result.sample(rng=rng)


def _coerce_rng(rng: random.Random | int | None) -> random.Random:
    if rng is None:
        return random.Random()
    if isinstance(rng, int):
        return random.Random(rng)
    return rng


def _sample_order(order_weights: tuple[tuple[int, float], ...], rng: random.Random) -> int:
    if not order_weights:
        return 0
    threshold = rng.random() * sum(weight for _, weight in order_weights)
    cumulative = 0.0
    chosen = order_weights[-1][0]
    for order, weight in order_weights:
        cumulative += weight
        if threshold <= cumulative:
            return order
    return chosen
